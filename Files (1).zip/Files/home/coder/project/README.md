<!DOCTYPE html>
<html> 
     <head>  
            <title> La création de ma première page en html </title>
            <style>
                 img { width: 50%};
            </style>
      </head>
      <body>
        <main>
           <h1> Les cours sont très bien dispensés </h1>
           <p> J'ai appris la création de page web </p>
           <p> Je suis toujours passionné au developpement web </p>
           <img src="R(7).jpg" alt="almor">
           <img src="img_chania.jpg" alt="Flowers in Chania">
           <img src="img_girl.jpg" alt="Girl in a jacket">
        </main>
      </body>
       <footer> Copyright par alasko family </footer>
 </html>